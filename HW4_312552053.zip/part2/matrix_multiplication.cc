#include <mpi.h>
#include <fstream>
#include <iostream>
#include <cstring>
#include <vector>

void construct_matrices(std::ifstream &in, int *n_ptr, int *m_ptr, int *l_ptr, int **a_mat_ptr, int **b_mat_ptr){
    if (!in) {
        std::cerr << "Error: Unable to open file for reading.\n";
        MPI_Abort(MPI_COMM_WORLD, 1);
    }

    in >> *n_ptr >> *m_ptr >> *l_ptr;

    //a_mat_ptr = new int[m][n];
    //b_mat_ptr = new int[n][l];

    //a_mat_ptr = (int**)malloc(m * sizeof(int*));
    //for (int i = 0; i < m ; i++) {        
    //    a_mat_ptr[i] = (int*)malloc(n * sizeof(int));
    //}
    //b_mat_ptr = (int*)malloc(n * sizeof(int*));
    //for (int i = 0; i < n; i++) {        
    //    b_mat_ptr[i] = (int*)malloc(l * sizeof(int));
    //}

    //for (int i = 0; i < m; ++i){
    //    for(int j = 0; j < n; j++){
    //        in >> a_mat_ptr[i][j];
    //    }
    //}
    //for (int i = 0; i < n; ++i){
    //    for(int j = 0; j < l; j++){
    //        in >> b_mat_ptr[i][j];
    //    }
    //}

    *a_mat_ptr = (int *)malloc((*n_ptr) * (*m_ptr) * sizeof(int));
    *b_mat_ptr = (int *)malloc((*m_ptr) * (*l_ptr) * sizeof(int));

    if (!(*a_mat_ptr) || !(*b_mat_ptr)) {
        std::cerr << "Error: Memory allocation failed.\n";
        MPI_Abort(MPI_COMM_WORLD, 1);
    }

    for (int i = 0; i < (*n_ptr) * (*m_ptr); ++i) {
        if (!(in >> (*a_mat_ptr)[i])) {
            std::cerr << "Error: Failed to read matrix A data.\n";
            MPI_Abort(MPI_COMM_WORLD, 1);
        }
    }

    for (int i = 0; i < (*m_ptr) * (*l_ptr); ++i) {
        if (!(in >> (*b_mat_ptr)[i])) {
            std::cerr << "Error: Failed to read matrix B data.\n";
            MPI_Abort(MPI_COMM_WORLD, 1);
        }
    }
}

void destruct_matrices(int *a_mat, int *b_mat) {
    free(a_mat);
    free(b_mat);
}

//void print_matrix(const int *mat, int rows, int cols, const char *name) {
//    cout << name << " (" << rows << "x" << cols << "):" << endl;
//    for (int i = 0; i < rows; ++i) {
//        for (int j = 0; j < cols; ++j) {
//            cout << mat[i * cols + j] << " ";
//        }
//        cout << endl;
//    }
//}

//void multiply_blocks(const int *A, const int *B, int *C, int rows, int m, int l) {
//    for (int i = 0; i < rows; ++i) {
//        for (int j = 0; j < l; ++j) {
//            for (int k = 0; k < m; ++k) {
//                C[i * l + j] += A[i * m + k] * B[k * l + j];
//            }
//        }
//    }
//}

void matrix_multiply(const int n, const int m, const int l, const int *a_mat, const int *b_mat) {
    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    // Determine row distribution for load balancing
    int rows_per_process = n / size;
    int extra_rows = n % size;

    int start_row = rank * rows_per_process + std::min(rank, extra_rows);
    int end_row = start_row + rows_per_process + (rank < extra_rows ? 1 : 0);

    int local_row_count = end_row - start_row;

    // Allocate space for local rows of A and the full matrix B
    std::vector<int> local_a(local_row_count * m);
    std::vector<int> local_c(local_row_count * l, 0); // Resulting rows of C
    memset(local_c.data(), 0, local_c.size() * sizeof(int));

    // Scatter rows of A to all processes
    std::vector<int> send_counts(size), displacements(size);
    for (int i = 0; i < size; ++i) {
        int rows = rows_per_process + (i < extra_rows ? 1 : 0);
        send_counts[i] = rows * m;
        displacements[i] = (i > 0) ? displacements[i - 1] + send_counts[i - 1] : 0;
    }

    MPI_Scatterv(a_mat, send_counts.data(), displacements.data(), MPI_INT,
                 local_a.data(), local_row_count * m, MPI_INT,
                 0, MPI_COMM_WORLD);

    // Broadcast the entire matrix B to all processes
    MPI_Bcast(const_cast<int *>(b_mat), m * l, MPI_INT, 0, MPI_COMM_WORLD);

    // Tiling for better cache utilization
    const int tile_size = 32; // Adjustable based on hardware and problem size
    for (int i = 0; i < local_row_count; i += tile_size) {
        for (int j = 0; j < l; j += tile_size) {
            for (int k = 0; k < m; k += tile_size) {
                // Compute a tile of the result
                for (int ii = i; ii < std::min(i + tile_size, local_row_count); ++ii) {
                    for (int jj = j; jj < std::min(j + tile_size, l); ++jj) {
                        int sum = 0;
                        for (int kk = k; kk < std::min(k + tile_size, m); ++kk) {
                            sum += local_a[ii * m + kk] * b_mat[kk * l + jj];
                        }
                        local_c[ii * l + jj] += sum;
                    }
                }
            }
        }
    }

    // Gather results from all processes
    std::vector<int> result_c;
    if (rank == 0) {
        result_c.resize(n * l);
    }

    std::vector<int> recv_counts(size), recv_displacements(size);
    for (int i = 0; i < size; ++i) {
        int rows = rows_per_process + (i < extra_rows ? 1 : 0);
        recv_counts[i] = rows * l;
        recv_displacements[i] = (i > 0) ? recv_displacements[i - 1] + recv_counts[i - 1] : 0;
    }

    MPI_Gatherv(local_c.data(), local_row_count * l, MPI_INT,
                result_c.data(), recv_counts.data(), recv_displacements.data(), MPI_INT,
                0, MPI_COMM_WORLD);

    // Print the resulting matrix if rank == 0
    if (rank == 0) {
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < l; ++j) {
                std::cout << result_c[i * l + j] << " ";
            }
            std::cout << "\n";
        }
    }
}

