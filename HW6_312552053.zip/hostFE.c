#include <stdio.h>
#include <stdlib.h>
#include "hostFE.h"
#include "helper.h"

void hostFE(int filterWidth, float *filter, int imageHeight, int imageWidth,
            float *inputImage, float *outputImage, cl_device_id *device,
            cl_context *context, cl_program *program)
{
    cl_int status;
    int filterPixels = filterWidth * filterWidth;
    
    size_t imagePixels = imageHeight * imageWidth * sizeof(float);
    size_t filterSize = filterPixels * sizeof(float);

    // Create a command queue
    cl_command_queue queue = clCreateCommandQueueWithProperties(*context, *device, 0, &status);
    if (status != CL_SUCCESS) {
        printf("Command Queue Fail.\n");
        return;
    }

    // Create buffers
    cl_mem inputBuffer = clCreateBuffer(*context, CL_MEM_READ_ONLY, imagePixels, NULL, &status);
    cl_mem outputBuffer = clCreateBuffer(*context, CL_MEM_WRITE_ONLY, imagePixels, NULL, &status);
    cl_mem filterBuffer = clCreateBuffer(*context, CL_MEM_READ_ONLY, filterSize, NULL, &status);

    // Copy data to buffers
    clEnqueueWriteBuffer(queue, inputBuffer, CL_TRUE, 0, imagePixels, inputImage, 0, NULL, NULL);
    clEnqueueWriteBuffer(queue, filterBuffer, CL_TRUE, 0, filterSize, filter, 0, NULL, NULL);

    // Create kernel
    cl_kernel kernel = clCreateKernel(*program, "convolution", &status);

    // Set kernel arguments
    clSetKernelArg(kernel, 0, sizeof(cl_mem), &inputBuffer);
    clSetKernelArg(kernel, 1, sizeof(cl_mem), &outputBuffer);
    clSetKernelArg(kernel, 2, sizeof(cl_mem), &filterBuffer);
    clSetKernelArg(kernel, 3, sizeof(int), &filterWidth);
    clSetKernelArg(kernel, 4, sizeof(int), &imageWidth);
    clSetKernelArg(kernel, 5, sizeof(int), &imageHeight);

    // Define global and local work sizes
    size_t globalWorkSize[2] = {imageHeight, imageWidth};

    // Launch kernel
    clEnqueueNDRangeKernel(queue, kernel, 2, NULL, globalWorkSize, NULL, 0, NULL, NULL);

    // Read back the output
    clEnqueueReadBuffer(queue, outputBuffer, CL_TRUE, 0, imagePixels, outputImage, 0, NULL, NULL);

    // Clean up
    clReleaseMemObject(inputBuffer);
    clReleaseMemObject(outputBuffer);
    clReleaseMemObject(filterBuffer);
    clReleaseKernel(kernel);

    // Release the command queue
    clReleaseCommandQueue(queue); 
}

//void hostFE(int filterWidth, float *filter, int imageHeight, int imageWidth,
//            float *inputImage, float *outputImage, cl_device_id *device,
//            cl_context *context, cl_program *program)
//{
//    cl_int status;
//    int filterPixels = filterWidth * filterWidth;
//
//    size_t imagePixels = imageHeight * imageWidth * sizeof(float);
//    size_t filterSize = filterPixels * sizeof(float);
//
//    // Create a command queue with profiling enabled
//    cl_command_queue_properties properties = CL_QUEUE_PROFILING_ENABLE;
//    cl_command_queue queue = clCreateCommandQueueWithProperties(*context, *device, &properties, &status);
//    if (status != CL_SUCCESS) {
//        printf("Command Queue Creation Failed.\n");
//        return;
//    }
//
//    // Create buffers
//    cl_mem inputBuffer = clCreateBuffer(*context, CL_MEM_READ_ONLY | CL_MEM_ALLOC_HOST_PTR, imagePixels, NULL, &status);
//    cl_mem outputBuffer = clCreateBuffer(*context, CL_MEM_WRITE_ONLY | CL_MEM_ALLOC_HOST_PTR, imagePixels, NULL, &status);
//    cl_mem filterBuffer = clCreateBuffer(*context, CL_MEM_READ_ONLY | CL_MEM_ALLOC_HOST_PTR, filterSize, NULL, &status);
//
//    // Copy data to buffers (non-blocking)
//    clEnqueueWriteBuffer(queue, inputBuffer, CL_FALSE, 0, imagePixels, inputImage, 0, NULL, NULL);
//    clEnqueueWriteBuffer(queue, filterBuffer, CL_FALSE, 0, filterSize, filter, 0, NULL, NULL);
//
//    // Create kernel
//    cl_kernel kernel = clCreateKernel(*program, "convolution", &status);
//
//    // Set kernel arguments
//    clSetKernelArg(kernel, 0, sizeof(cl_mem), &inputBuffer);
//    clSetKernelArg(kernel, 1, sizeof(cl_mem), &outputBuffer);
//    clSetKernelArg(kernel, 2, sizeof(cl_mem), &filterBuffer);
//    clSetKernelArg(kernel, 3, sizeof(int), &filterWidth);
//    clSetKernelArg(kernel, 4, sizeof(int), &imageWidth);
//    clSetKernelArg(kernel, 5, sizeof(int), &imageHeight);
//
//    // Define global and local work sizes
//    size_t globalWorkSize[2] = {imageHeight, imageWidth};
//    size_t localWorkSize[2] = {16, 16}; // Example, tune this based on device
//
//    // Launch kernel
//    clEnqueueNDRangeKernel(queue, kernel, 2, NULL, globalWorkSize, localWorkSize, 0, NULL, NULL);
//
//    // Read back the output (non-blocking)
//    clEnqueueReadBuffer(queue, outputBuffer, CL_FALSE, 0, imagePixels, outputImage, 0, NULL, NULL);
//
//    // Ensure all commands complete
//    clFinish(queue);
//
//    // Clean up
//    clReleaseMemObject(inputBuffer);
//    clReleaseMemObject(outputBuffer);
//    clReleaseMemObject(filterBuffer);
//    clReleaseKernel(kernel);
//    clReleaseCommandQueue(queue); 
//}
