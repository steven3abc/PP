#include <stdio.h>
#include <stdlib.h>
#include "hostFE.h"
#include "helper.h"

void hostFE(int filterWidth, float *filter, int imageHeight, int imageWidth,
            float *inputImage, float *outputImage, cl_device_id *device,
            cl_context *context, cl_program *program)
{
    cl_int status;
    int filterSize = filterWidth * filterWidth;

    
    size_t imageSize = imageHeight * imageWidth * sizeof(float);
    size_t filterSizeBytes = filterSize * sizeof(float);

    // Create a command queue
    cl_command_queue queue = clCreateCommandQueueWithProperties(*context, *device, 0, &status);
    if (status != CL_SUCCESS) {
        printf("Failed to create command queue.\n");
        return;
    }

    // Create buffers
    cl_mem inputBuffer = clCreateBuffer(*context, CL_MEM_READ_ONLY, imageSize, NULL, &status);
    cl_mem outputBuffer = clCreateBuffer(*context, CL_MEM_WRITE_ONLY, imageSize, NULL, &status);
    cl_mem filterBuffer = clCreateBuffer(*context, CL_MEM_READ_ONLY, filterSizeBytes, NULL, &status);

    // Copy data to buffers
    clEnqueueWriteBuffer(queue, inputBuffer, CL_TRUE, 0, imageSize, inputImage, 0, NULL, NULL);
    clEnqueueWriteBuffer(queue, filterBuffer, CL_TRUE, 0, filterSizeBytes, filter, 0, NULL, NULL);

    // Create kernel
    cl_kernel kernel = clCreateKernel(*program, "convolution", &status);

    // Set kernel arguments
    clSetKernelArg(kernel, 0, sizeof(cl_mem), &inputBuffer);
    clSetKernelArg(kernel, 1, sizeof(cl_mem), &outputBuffer);
    clSetKernelArg(kernel, 2, sizeof(cl_mem), &filterBuffer);
    clSetKernelArg(kernel, 3, sizeof(int), &filterWidth);
    clSetKernelArg(kernel, 4, sizeof(int), &imageWidth);
    clSetKernelArg(kernel, 5, sizeof(int), &imageHeight);

    // Define global and local work sizes
    size_t globalWorkSize[2] = {imageHeight, imageWidth};

    // Launch kernel
    clEnqueueNDRangeKernel(queue, kernel, 2, NULL, globalWorkSize, NULL, 0, NULL, NULL);

    // Read back the output
    clEnqueueReadBuffer(queue, outputBuffer, CL_TRUE, 0, imageSize, outputImage, 0, NULL, NULL);

    // Clean up
    clReleaseMemObject(inputBuffer);
    clReleaseMemObject(outputBuffer);
    clReleaseMemObject(filterBuffer);
    clReleaseKernel(kernel);
    clReleaseCommandQueue(queue); // Release the command queue
}