#include <stdio.h>
#include <cstdlib>
#include <ctime> 
#include <pthread.h>


//int main(){
//    long long int number_of_tosses = 100000000;
//    long long int number_in_circle = 0;
//    srand( time(NULL) );
//    for(int i = 0; i < number_of_tosses; i++){
//        double x = (double)rand() / RAND_MAX * 2 - 1;
//        double y = (double)rand() / RAND_MAX * 2 - 1;
//        //std::cout << "x = " << x << std::endl;
//        //std::cout << "y = " << y << std::endl;
//        //std::cout << "RAND_MAX = " << RAND_MAX << std::endl;
//        double distance_squared = x * x + y * y;
//        if(distance_squared <= 1){
//            number_in_circle++;
//        }
//    }
//    double estimate_pi = 4 * number_in_circle/((double)number_of_tosses);
//    printf("%1.4f\n", estimate_pi);
//    return 0;
//}

typedef struct {
    long long int number_of_tosses;
    long long int number_in_circle;
    unsigned int r_seed;  // Seed for random number generator
} ThreadData;

void* monte_carlo_thread(void* arg) {
    ThreadData* data = (ThreadData*)arg;
    long long int valid = 0;
    
    for (long long int i = 0; i < data->number_of_tosses; ++i) {
        double x = (double)rand_r(&data->r_seed) / RAND_MAX * 2 - 1;
        double y = (double)rand_r(&data->r_seed) / RAND_MAX * 2 - 1;
        double distance_squared = x * x + y * y;
        if (distance_squared <= 1) {
            valid++;
        }
    }

    data->number_in_circle = valid; 
    pthread_exit(NULL);
    //return 0;
}

double estimate_pi(long long int number_of_tosses, int num_threads, pthread_attr_t *attr) {
    pthread_t threads[num_threads];
    ThreadData thread_data[num_threads];
    
    long long int tosses_per_thread = number_of_tosses / num_threads;
    
    // Initialize and create threads
    for (int i = 0; i < num_threads; ++i) {
        thread_data[i].number_of_tosses = tosses_per_thread;
        thread_data[i].number_in_circle = 0;
        thread_data[i].r_seed = (unsigned int)time(NULL) ^ (i * i);  // Unique seed for each thread
        pthread_create(&threads[i], attr, monte_carlo_thread, &thread_data[i]);
    }
    
    // Wait for all threads to finish
    long long int total_in_circle = 0;
    for (int i = 0; i < num_threads; ++i) {
        pthread_join(threads[i], NULL);
        total_in_circle += thread_data[i].number_in_circle;        
    }       
    
    // Estimate Pi
    return 4.0 * (double)total_in_circle / (double)number_of_tosses;
}

int main(int argc, char* argv[]) {
    pthread_attr_t attr;
    pthread_attr_init(&attr);
    pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_JOINABLE);

    if (argc != 3) {
        printf("Wrong arg number\n");
        return -1;
    }

    int num_threads = atoi(argv[1]);
    long long int number_of_tosses = atoll(argv[2]);

    if (num_threads < 1 || num_threads > 6) {
        printf("number of threads must be 1 to 6.\n");
        return -1;
    }

    double pi_estimate = estimate_pi(number_of_tosses, num_threads, &attr);
    printf("%1.7f\n", pi_estimate);
    return 0;
}