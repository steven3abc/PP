#include <mpi.h>
#include <fstream>
#include <iostream>
#include <cstring>
#include <vector>

void construct_matrices(std::ifstream &in, int *n_ptr, int *m_ptr, int *l_ptr, int **a_mat_ptr, int **b_mat_ptr){
    if (!in) {
        std::cerr << "Error: Unable to open file for reading.\n";
        MPI_Abort(MPI_COMM_WORLD, 1);
    }

    in >> *n_ptr >> *m_ptr >> *l_ptr;

    if (*n_ptr <= 0 || *m_ptr <= 0 || *l_ptr <= 0) {
        std::cerr << "Error: Invalid matrix dimensions.\n";
        MPI_Abort(MPI_COMM_WORLD, 1);
    }

    *a_mat_ptr = new int[(*n_ptr) * (*m_ptr)];
    *b_mat_ptr = new int[(*m_ptr) * (*l_ptr)];

    if (!(*a_mat_ptr) || !(*b_mat_ptr)) {
        std::cerr << "Error: Memory allocation failed.\n";
        MPI_Abort(MPI_COMM_WORLD, 1);
    }

    for (int i = 0; i < (*n_ptr) * (*m_ptr); ++i) {
        if (!(in >> (*a_mat_ptr)[i])) {
            std::cerr << "Error: Failed to read matrix A data.\n";
            MPI_Abort(MPI_COMM_WORLD, 1);
        }
    }

    for (int i = 0; i < (*m_ptr) * (*l_ptr); ++i) {
        if (!(in >> (*b_mat_ptr)[i])) {
            std::cerr << "Error: Failed to read matrix B data.\n";
            MPI_Abort(MPI_COMM_WORLD, 1);
        }
    }
}

void destruct_matrices(int *a_mat, int *b_mat) {
    delete[] a_mat;
    delete[] b_mat;
}

//void print_matrix(const int *mat, int rows, int cols, const char *name) {
//    cout << name << " (" << rows << "x" << cols << "):" << endl;
//    for (int i = 0; i < rows; ++i) {
//        for (int j = 0; j < cols; ++j) {
//            cout << mat[i * cols + j] << " ";
//        }
//        cout << endl;
//    }
//}

//void multiply_blocks(const int *A, const int *B, int *C, int rows, int m, int l) {
//    for (int i = 0; i < rows; ++i) {
//        for (int j = 0; j < l; ++j) {
//            for (int k = 0; k < m; ++k) {
//                C[i * l + j] += A[i * m + k] * B[k * l + j];
//            }
//        }
//    }
//}

void matrix_multiply(const int n, const int m, const int l, const int *a_mat, const int *b_mat) {
    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    int rows_per_process = n / size;
    int remaining_rows = n % size;

    int start_row = rank * rows_per_process + std::min(rank, remaining_rows);
    int end_row = start_row + rows_per_process + (rank < remaining_rows ? 1 : 0);

    int local_row_count = end_row - start_row;

    std::vector<int> local_a(local_row_count * m);
    std::vector<int> local_c(local_row_count * l, 0); // Resulting rows of C

    std::vector<int> send_counts(size), displacements(size);
    for (int i = 0; i < size; ++i) {
        int rows = rows_per_process + (i < remaining_rows ? 1 : 0);
        send_counts[i] = rows * m;
        displacements[i] = (i > 0) ? displacements[i - 1] + send_counts[i - 1] : 0;
    }

    MPI_Scatterv(a_mat, send_counts.data(), displacements.data(), MPI_INT,
                 local_a.data(), local_row_count * m, MPI_INT,
                 0, MPI_COMM_WORLD);

    MPI_Bcast(const_cast<int *>(b_mat), m * l, MPI_INT, 0, MPI_COMM_WORLD);

    for (int i = 0; i < local_row_count; ++i) {
        for (int j = 0; j < l; ++j) {
            for (int k = 0; k < m; ++k) {
                local_c[i * l + j] += local_a[i * m + k] * b_mat[k * l + j];
            }
        }
    }

    std::vector<int> result_c;
    if (rank == 0) {
        result_c.resize(n * l);
    }

    std::vector<int> recv_counts(size), recv_displacements(size);
    for (int i = 0; i < size; ++i) {
        int rows = rows_per_process + (i < remaining_rows ? 1 : 0);
        recv_counts[i] = rows * l;
        recv_displacements[i] = (i > 0) ? recv_displacements[i - 1] + recv_counts[i - 1] : 0;
    }

    MPI_Gatherv(local_c.data(), local_row_count * l, MPI_INT,
                result_c.data(), recv_counts.data(), recv_displacements.data(), MPI_INT,
                0, MPI_COMM_WORLD);

    if (rank == 0) {
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < l; ++j) {
                std::cout << result_c[i * l + j] << " ";
            }
            std::cout << "\n";
        }
    }
}

