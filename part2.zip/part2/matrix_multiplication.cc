#include <mpi.h>
#include <fstream>
#include <iostream>
#include <cstring>
#include <vector>
using namespace std;

void construct_matrices(std::ifstream &in, int *n_ptr, int *m_ptr, int *l_ptr, int **a_mat_ptr, int **b_mat_ptr){
    in >> *n_ptr >> *m_ptr >> *l_ptr;

    int n = *n_ptr, m = *m_ptr, l = *l_ptr;

    //a_mat_ptr = new int[m][n];
    //b_mat_ptr = new int[n][l];

    //a_mat_ptr = (int**)malloc(m * sizeof(int*));
    //for (int i = 0; i < m ; i++) {        
    //    a_mat_ptr[i] = (int*)malloc(n * sizeof(int));
    //}
    //b_mat_ptr = (int*)malloc(n * sizeof(int*));
    //for (int i = 0; i < n; i++) {        
    //    b_mat_ptr[i] = (int*)malloc(l * sizeof(int));
    //}

    //for (int i = 0; i < m; ++i){
    //    for(int j = 0; j < n; j++){
    //        in >> a_mat_ptr[i][j];
    //    }
    //}
    //for (int i = 0; i < n; ++i){
    //    for(int j = 0; j < l; j++){
    //        in >> b_mat_ptr[i][j];
    //    }
    //}
    *a_mat_ptr = (int*)malloc(n * m * sizeof(int));
    *b_mat_ptr = (int*)malloc(m * l * sizeof(int));
    for (int i = 0; i < m * n; ++i){
        in >> *a_mat_ptr[i];
    }
    for (int i = 0; i < n * l; ++i){
        in >> *b_mat_ptr[i];
    }
     
}

void destruct_matrices(int *a_mat, int *b_mat) {
    delete[] a_mat;
    delete[] b_mat;
}

//void print_matrix(const int *mat, int rows, int cols, const char *name) {
//    cout << name << " (" << rows << "x" << cols << "):" << endl;
//    for (int i = 0; i < rows; ++i) {
//        for (int j = 0; j < cols; ++j) {
//            cout << mat[i * cols + j] << " ";
//        }
//        cout << endl;
//    }
//}

void multiply_blocks(const int *A, const int *B, int *C, int rows, int m, int l) {
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < l; ++j) {
            for (int k = 0; k < m; ++k) {
                C[i * l + j] += A[i * m + k] * B[k * l + j];
            }
        }
    }
}

void matrix_multiply(const int n, const int m, const int l, const int *a_mat, const int *b_mat) {
    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    // Determine row distribution
    vector<int> send_counts(size), displacements(size);
    int base_rows = n / size;
    int remainder = n % size;

    for (int i = 0; i < size; ++i) {
        send_counts[i] = (i < remainder ? base_rows + 1 : base_rows) * m;
        displacements[i] = (i == 0) ? 0 : displacements[i - 1] + send_counts[i - 1];
    }

    // Receive count for this process
    int local_rows = send_counts[rank] / m;
    vector<int> local_A(local_rows * m);
    vector<int> local_C(local_rows * l, 0);
    vector<int> B(m * l);

    // Scatter rows of A among processes
    MPI_Scatterv(a_mat, send_counts.data(), displacements.data(), MPI_INT, local_A.data(), send_counts[rank], MPI_INT, 0, MPI_COMM_WORLD);

    // Broadcast matrix B to all processes
    MPI_Bcast(B.data(), m * l, MPI_INT, 0, MPI_COMM_WORLD);

    // Perform local multiplication
    multiply_blocks(local_A.data(), B.data(), local_C.data(), local_rows, m, l);

    // Gather the results
    vector<int> recv_counts(size), recv_displs(size);
    for (int i = 0; i < size; ++i) {
        recv_counts[i] = (i < remainder ? base_rows + 1 : base_rows) * l;
        recv_displs[i] = (i == 0) ? 0 : recv_displs[i - 1] + recv_counts[i - 1];
    }

    vector<int> C;
    if (rank == 0) {
        C.resize(n * l);
    }
    MPI_Gatherv(local_C.data(), recv_counts[rank], MPI_INT, C.data(), recv_counts.data(), recv_displs.data(), MPI_INT, 0, MPI_COMM_WORLD);

    // Print the result matrix
    if (rank == 0) {
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < l; ++j) {
                cout << C[i * l + j] << " ";
            }
            cout << endl;
        }
    }
}

