#include <mpi.h>
#include <iostream>
#include <vector>
#include <cstring>

void matrix_multiply(const int n, const int m, const int l,
                     const int *a_mat, const int *b_mat) {
    int rank, size;

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    // Each process calculates a subset of rows of C
    int rows_per_proc = n / size;
    int remaining_rows = n % size;

    int start_row = rank * rows_per_proc + (rank < remaining_rows ? rank : remaining_rows);
    int end_row = start_row + rows_per_proc + (rank < remaining_rows ? 1 : 0);

    int local_rows = end_row - start_row;

    // Allocate memory for local part of result matrix C
    int *local_c = new int[local_rows * l];
    memset(local_c, 0, local_rows * l * sizeof(int));

    // Broadcast matrix B to all processes
    int *b_global = const_cast<int*>(b_mat);
    MPI_Bcast(b_global, m * l, MPI_INT, 0, MPI_COMM_WORLD);

    // Perform local matrix multiplication
    for (int i = 0; i < local_rows; ++i) {
        for (int j = 0; j < l; ++j) {
            for (int k = 0; k < m; ++k) {
                local_c[i * l + j] += a_mat[(start_row + i) * m + k] * b_global[k * l + j];
            }
        }
    }

    // Gather results at root process
    int *recv_counts = nullptr;
    int *displs = nullptr;
    int *global_c = nullptr;

    if (rank == 0) {
        recv_counts = new int[size];
        displs = new int[size];
        global_c = new int[n * l];

        for (int p = 0; p < size; ++p) {
            int p_rows = rows_per_proc + (p < remaining_rows ? 1 : 0);
            recv_counts[p] = p_rows * l;
            displs[p] = (p > 0 ? displs[p - 1] + recv_counts[p - 1] : 0);
        }
    }

    MPI_Gatherv(local_c, local_rows * l, MPI_INT,
                global_c, recv_counts, displs, MPI_INT, 0, MPI_COMM_WORLD);

    // Output the result matrix at the root process
    if (rank == 0) {
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < l; ++j) {
                std::cout << global_c[i * l + j] << " ";
            }
            std::cout << "\n";
        }

        // Free allocated memory
        delete[] global_c;
        delete[] recv_counts;
        delete[] displs;
    }

    delete[] local_c;
}

void construct_matrices(std::ifstream &in, int *n_ptr, int *m_ptr, int *l_ptr,
                        int **a_mat_ptr, int **b_mat_ptr) {
    in >> *n_ptr >> *m_ptr >> *l_ptr;

    int n = *n_ptr, m = *m_ptr, l = *l_ptr;

    *a_mat_ptr = new int[n * m];
    *b_mat_ptr = new int[m * l];

    for (int i = 0; i < n * m; ++i)
        in >> (*a_mat_ptr)[i];

    for (int i = 0; i < m * l; ++i)
        in >> (*b_mat_ptr)[i];
}

void destruct_matrices(int *a_mat, int *b_mat) {
    delete[] a_mat;
    delete[] b_mat;
}
