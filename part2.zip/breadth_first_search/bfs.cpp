#include "bfs.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <cstddef>
#include <omp.h>

#include "../common/CycleTimer.h"
#include "../common/graph.h"

#define ROOT_NODE_ID 0
#define NOT_VISITED_MARKER -1

void vertex_set_clear(vertex_set *list)
{
    list->count = 0;
}

void vertex_set_init(vertex_set *list, int count)
{
    list->max_vertices = count;
    list->vertices = (int *)malloc(sizeof(int) * list->max_vertices);
    vertex_set_clear(list);
}

// Take one step of "top-down" BFS.  For each vertex on the frontier,
// follow all outgoing edges, and add all neighboring vertices to the
// new_frontier.
void top_down_step(
    Graph g,
    vertex_set *frontier,
    vertex_set *new_frontier,
    int *distances)
{
    // Allocate thread-local storage for each thread's contributions
    int max_threads = omp_get_max_threads();
    int *local_counts = (int *)calloc(max_threads, sizeof(int));
    int **local_vertices = (int **)malloc(max_threads * sizeof(int*));

    // Allocate space for each thread's list of new frontier nodes
    #pragma omp parallel for
    for (int i = 0; i < max_threads; i++) {
        local_vertices[i] = (int *)malloc(frontier->max_vertices * sizeof(int));
    }

    // Parallelize the loop over the frontier nodes
    #pragma omp parallel
    {
        int tid = omp_get_thread_num();
        int local_count = 0;

        #pragma omp for schedule(dynamic, 1024)
        for (int i = 0; i < frontier->count; i++) {
            int node = frontier->vertices[i];
            int start_edge = g->outgoing_starts[node];
            int end_edge = (node == g->num_nodes - 1) ? g->num_edges : g->outgoing_starts[node + 1];

            // Loop over all neighbors of this node
            for (int neighbor = start_edge; neighbor < end_edge; neighbor++) {
                int outgoing = g->outgoing_edges[neighbor];

                // Check if the node has not been visited
                if (distances[outgoing] == NOT_VISITED_MARKER) {
                    //#pragma omp critical
                    {
                        if (distances[outgoing] == NOT_VISITED_MARKER) {
                            // Mark the node as visited with the distance
                            
                            int new_dis = distances[node] + 1;
                            #pragma omp atomic write
                            distances[outgoing] = new_dis;
                            
                            

                            // Add this node to the thread's local frontier
                            local_vertices[tid][local_count++] = outgoing;
                        }
                    }
                }
            }
        }

        // Save the local count for this thread
        local_counts[tid] = local_count;
    }

    // Combine all local frontiers into the global new_frontier
    int total_count = 0;
    for (int i = 0; i < max_threads; i++) {
        for (int j = 0; j < local_counts[i]; j++) {
            new_frontier->vertices[total_count++] = local_vertices[i][j];
        }
    }
    new_frontier->count = total_count;

    // Free thread-local storage
    #pragma omp parallel for
    for (int i = 0; i < max_threads; i++) {
        free(local_vertices[i]);
    }
    free(local_vertices);
    free(local_counts);
}



void top_down_step_original(
    Graph g,
    vertex_set *frontier,
    vertex_set *new_frontier,
    int *distances)
{
    //int local_new_vertices[MAX_VERTICES];
    //int local_count = 0;
    //#pragma omp parallel for
    for (int i = 0; i < frontier->count; i++)
    {
        int node = frontier->vertices[i];

        int start_edge = g->outgoing_starts[node];
        int end_edge = (node == g->num_nodes - 1)
                           ? g->num_edges
                           : g->outgoing_starts[node + 1];

        // attempt to add all neighbors to the new frontier
        //#pragma omp parallel for
        //#pragma omp parallel for schedule(dynamic, 1024)
        for (int neighbor = start_edge; neighbor < end_edge; neighbor++)
        {
            int outgoing = g->outgoing_edges[neighbor];
            //#pragma omp critical
            //{
            if (distances[outgoing] == NOT_VISITED_MARKER)
            {
                distances[outgoing] = distances[node] + 1;
                #pragma omp critical
                {
                    int index = new_frontier->count++;
                    new_frontier->vertices[index] = outgoing;
                }                                   
                
            }
            //}
            
        }
    }
}

// Implements top-down BFS.
//
// Result of execution is that, for each node in the graph, the
// distance to the root is stored in sol.distances.
void bfs_top_down(Graph graph, solution *sol)
{

    vertex_set list1;
    vertex_set list2;
    vertex_set_init(&list1, graph->num_nodes);
    vertex_set_init(&list2, graph->num_nodes);

    vertex_set *frontier = &list1;
    vertex_set *new_frontier = &list2;

    // initialize all nodes to NOT_VISITED
    #pragma omp parallel for
    for (int i = 0; i < graph->num_nodes; i++)
        sol->distances[i] = NOT_VISITED_MARKER;
    //memset(sol->distances, NOT_VISITED_DISTANCE, graph->num_nodes * sizeof(int));
    // setup frontier with the root node
    frontier->vertices[frontier->count++] = ROOT_NODE_ID;
    sol->distances[ROOT_NODE_ID] = 0;

    while (frontier->count != 0)
    {

#ifdef VERBOSE
        double start_time = CycleTimer::currentSeconds();
#endif

        vertex_set_clear(new_frontier);

        top_down_step(graph, frontier, new_frontier, sol->distances);

#ifdef VERBOSE
        double end_time = CycleTimer::currentSeconds();
        printf("frontier=%-10d %.4f sec\n", frontier->count, end_time - start_time);
#endif

        // swap pointers
        vertex_set *tmp = frontier;
        frontier = new_frontier;
        new_frontier = tmp;
    }
}

void bottom_up_step(
    Graph g,
    vertex_set *frontier,
    vertex_set *new_frontier,
    int *distances,
    int current_distance)
{
    int max_threads = omp_get_max_threads();
    int *local_counts = (int *)calloc(max_threads, sizeof(int));
    int **local_vertices = (int **)malloc(max_threads * sizeof(int*));

    #pragma omp parallel for
    for (int i = 0; i < max_threads; i++) {
        local_vertices[i] = (int *)malloc(g->num_nodes * sizeof(int));
    }

    #pragma omp parallel
    {
        int tid = omp_get_thread_num();
        
        // Allocate thread-local storage for each thread's list of new frontier nodes
        //if (tid == 0) {
        //    for (int i = 0; i < max_threads; i++) {
        //        local_vertices[i] = (int *)malloc(g->num_nodes * sizeof(int));
        //    }
        //}
        //#pragma omp barrier

        int local_count = 0;

        // Parallelize over all nodes in the graph
        #pragma omp for schedule(dynamic, 1024) nowait
        for (int node = 0; node < g->num_nodes; node++) {
            if (distances[node] == NOT_VISITED_MARKER) {
                int start_edge = g->incoming_starts[node];
                int end_edge = (node == g->num_nodes - 1) ? g->num_edges : g->incoming_starts[node + 1];

                // Check if any incoming neighbor is in the current frontier
                for (int neighbor = start_edge; neighbor < end_edge; neighbor++) {
                    int incoming = g->incoming_edges[neighbor];

                    // If a neighbor is in the frontier, mark node as visited
                    if (distances[incoming] == current_distance) {
                        // Update distances using atomic to avoid conflicts
                        #pragma omp atomic write
                        distances[node] = current_distance + 1;

                        // Add this node to the local list of new frontier nodes
                        local_vertices[tid][local_count++] = node;
                        break;  // Stop once we find a valid neighbor
                    }
                }
            }
        }

        // Store the count of each thread's new frontier nodes
        local_counts[tid] = local_count;

        // Synchronize threads before merging
    }//#pragma omp barrier

    // Merge local frontiers into the global new_frontier in a single thread
    //#pragma omp single
    //{
        int total_count = 0;
        for (int i = 0; i < max_threads; i++) {
            for (int j = 0; j < local_counts[i]; j++) {
                new_frontier->vertices[total_count++] = local_vertices[i][j];
            }
        }
        new_frontier->count = total_count;
    //}
    // Free each thread's allocated space in a single thread to avoid memory issues
    #pragma omp parallel for
    for (int i = 0; i < max_threads; i++) {
        free(local_vertices[i]);
    }
        
    //}

    // Free the memory used for local_counts and local_vertices
    free(local_counts);
    free(local_vertices);
}

void bfs_bottom_up(Graph graph, solution *sol)
{
    // For PP students:
    //
    // You will need to implement the "bottom up" BFS here as
    // described in the handout.
    //
    // As a result of your code's execution, sol.distances should be
    // correctly populated for all nodes in the graph.
    //
    // As was done in the top-down case, you may wish to organize your
    // code by creating subroutine bottom_up_step() that is called in
    // each step of the BFS process.
    vertex_set list1;
    vertex_set list2;
    vertex_set_init(&list1, graph->num_nodes);
    vertex_set_init(&list2, graph->num_nodes);

    vertex_set *frontier = &list1;
    vertex_set *new_frontier = &list2;

    // Initialize all nodes to NOT_VISITED
    memset(sol->distances, NOT_VISITED_MARKER, graph->num_nodes * sizeof(int));

    // Set up frontier with the root node
    frontier->vertices[frontier->count++] = ROOT_NODE_ID;
    sol->distances[ROOT_NODE_ID] = 0;

    int current_distance = 0;

    while (frontier->count != 0) {
        vertex_set_clear(new_frontier);

        // Perform one step of the bottom-up BFS
        bottom_up_step(graph, frontier, new_frontier, sol->distances, current_distance);

        // Move to the next level
        current_distance++;

        // Swap pointers for the next iteration
        vertex_set *tmp = frontier;
        frontier = new_frontier;
        new_frontier = tmp;
    }

    // Free memory for vertex sets
    free(list1.vertices);
    free(list2.vertices);
}

void bfs_hybrid(Graph graph, solution *sol)
{
    // For PP students:
    //
    // You will need to implement the "hybrid" BFS here as
    // described in the handout.
    const float SWITCH_THRESHOLD = 0.1; // 10% of the graph size

    // Initialize the vertex sets
    vertex_set list1;
    vertex_set list2;
    vertex_set_init(&list1, graph->num_nodes);
    vertex_set_init(&list2, graph->num_nodes);

    vertex_set *frontier = &list1;
    vertex_set *new_frontier = &list2;

    // Initialize all nodes to NOT_VISITED
    memset(sol->distances, NOT_VISITED_MARKER, graph->num_nodes * sizeof(int));

    // Start with the root node
    frontier->vertices[frontier->count++] = ROOT_NODE_ID;
    sol->distances[ROOT_NODE_ID] = 0;

    int current_distance = 0;

    while (frontier->count > 0) {

        // Decide between top-down or bottom-up based on the frontier size
        bool use_bottom_up = (float)frontier->count / graph->num_nodes > SWITCH_THRESHOLD;

        // Clear the new frontier before each step
        vertex_set_clear(new_frontier);

        if (use_bottom_up) {
            // Perform a bottom-up step
            bottom_up_step(graph, frontier, new_frontier, sol->distances, current_distance);
        } else {
            // Perform a top-down step
            top_down_step(graph, frontier, new_frontier, sol->distances);
        }

        // Increment the distance after each BFS level
        current_distance++;

        // Swap the frontiers: old frontier becomes new, new becomes empty for next step
        vertex_set *tmp = frontier;
        frontier = new_frontier;
        new_frontier = tmp;
    }

    // Free memory used by vertex sets
    free(list1.vertices);
    free(list2.vertices);
}
