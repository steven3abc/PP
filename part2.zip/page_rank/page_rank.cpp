#include "page_rank.h"

#include <stdlib.h>
#include <cmath>
#include <omp.h>
#include <utility>

#include "../common/CycleTimer.h"
#include "../common/graph.h"

// pageRank --
//
// g:           graph to process (see common/graph.h)
// solution:    array of per-vertex vertex scores (length of array is num_nodes(g))
// damping:     page-rank algorithm's damping parameter
// convergence: page-rank algorithm's convergence threshold
//
void pageRank(Graph g, double *solution, double damping, double convergence)
{

    // initialize vertex weights to uniform probability. Double
    // precision scores are used to avoid underflow for large graphs

    int numNodes = num_nodes(g);
    double equal_prob = 1.0 / numNodes;
    double *pre_sol = (double*) malloc(numNodes * sizeof(double));
    bool converged = false;

    #pragma omp parallel for
    for (int i = 0; i < numNodes; ++i)
    {
      solution[i] = equal_prob;
    }

    /*
       For PP students: Implement the page rank algorithm here.  You
       are expected to parallelize the algorithm using openMP.  Your
       solution may need to allocate (and free) temporary arrays.

       Basic page rank pseudocode is provided below to get you started:*/

       // initialization: see example code above
       //score_old[vi] = 1/numNodes;
       //  

    while (!converged) {    
        #pragma omp parallel for
        for (int i = 0; i < numNodes; ++i) {
            pre_sol[i] = solution[i];
            solution[i] = 0.0;
        } 
       //  // compute score_new[vi] for all nodes vi:
       //  score_new[vi] = sum over all nodes vj reachable from incoming edges
       //                     { score_old[vj] / number of edges leaving vj  }
        #pragma omp parallel for
        for (int i = 0; i < numNodes; ++i) {
            const Vertex* begin = incoming_begin(g, i);
            const Vertex* end = incoming_end(g, i);

            for (const Vertex* v = begin; v < end; ++v) {
                int src = *v; 
                int out_degree = outgoing_size(g, src);
                if (out_degree > 0) {
                    double contribution = pre_sol[src] / out_degree;
                    #pragma omp atomic
                    solution[i] += contribution;
                }
            }
        }
       //  score_new[vi] = (damping * score_new[vi]) + (1.0-damping) / numNodes;
        double no_out_sum = 0.0;
        #pragma omp parallel for reduction(+:no_out_sum)
        for (int i = 0; i < numNodes; ++i) {
            if (outgoing_size(g, i) == 0) {
                no_out_sum += pre_sol[i];
            }
        }

        #pragma omp parallel for
        for (int i = 0; i < numNodes; ++i) {
            solution[i] = damping * solution[i] + (1.0 - damping) / numNodes;
            solution[i] += damping * no_out_sum / numNodes;
        }

       //  score_new[vi] += sum over all nodes v in graph with no outgoing edges
       //                     { damping * score_old[v] / numNodes }
       //
       //  // compute how much per-node scores have changed
       //  // quit once algorithm has converged
       //
       //  global_diff = sum over all nodes vi { abs(score_new[vi] - score_old[vi]) };
       //  converged = (global_diff < convergence)
       double global_diff = 0.0;
          #pragma omp parallel for reduction(+:global_diff)
          for (int i = 0; i < numNodes; ++i) {
              global_diff += fabs(solution[i] - pre_sol[i]);
          }
  
          converged = (global_diff < convergence);
    }
    free(pre_sol);
   
}
